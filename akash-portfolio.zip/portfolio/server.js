require('dotenv').config();
const path = require('path');
const express = require('express');
const mongoose = require('mongoose');

const Project = mongoose.model('Project', new mongoose.Schema({
  title: String, description: String, tech: [String],
  github: { type: String, default: '' }, live: { type: String, default: '' }, order: Number
}));
const Message = mongoose.model('Message', new mongoose.Schema({
  name: String, email: String, message: String, createdAt: { type: Date, default: Date.now }
}));

// Seed data (from resume). Add your repo URLs in `github` / `live`, or edit the DB later.
const seed = [
  { order: 1, title: 'Lung Cancer Prediction System', tech: ['Python', 'scikit-learn', 'pandas', 'NumPy', 'Matplotlib'],
    description: 'A machine learning system that predicts the likelihood of lung cancer from patient symptom and lifestyle data. Includes data cleaning, exploratory analysis, and a comparison of classification models using accuracy, precision, recall, and F1-score.' },
  { order: 2, title: 'Matrix Multiplication using GPU', tech: ['CUDA', 'C++'],
    description: 'Parallel matrix multiplication on the GPU, spreading the work across thousands of threads. Benchmarked against a sequential CPU version, with thread and block organization tuned for performance.' },
  { order: 3, title: 'Tic-Tac-Toe Game', tech: ['Python'],
    description: 'An interactive turn-based game with win and draw detection, move validation, and replay handling, organized into reusable functions.' }
];

const app = express();
app.use(express.json({ limit: '10kb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/projects', async (_req, res) => {
  try { res.json(await Project.find().sort('order').lean()); }
  catch { res.status(500).json({ error: 'Could not load projects.' }); }
});

app.post('/api/contact', async (req, res) => {
  const { name = '', email = '', message = '' } = req.body || {};
  const ok = name.trim() && /^\S+@\S+\.\S+$/.test(email) && message.trim().length >= 10;
  if (!ok) return res.status(400).json({ error: 'Enter your name, a valid email, and a message of at least 10 characters.' });
  try {
    await Message.create({ name: name.trim().slice(0, 100), email: email.trim().slice(0, 200), message: message.trim().slice(0, 2000) });
    res.status(201).json({ ok: true });
  } catch { res.status(500).json({ error: 'Message not sent. Try again in a moment.' }); }
});

(async () => {
  if (!process.env.MONGODB_URI) { console.error('Set MONGODB_URI in .env first.'); process.exit(1); }
  await mongoose.connect(process.env.MONGODB_URI);
  if (!(await Project.countDocuments())) await Project.insertMany(seed);
  app.listen(process.env.PORT || 3000, () => console.log('Portfolio running'));
})();
