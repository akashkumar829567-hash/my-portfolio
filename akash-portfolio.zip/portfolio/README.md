# Akash Kumar – Portfolio

Stack: HTML/CSS/JS frontend, Node.js + Express backend, MongoDB (Mongoose).

## Run locally
1. Create a free cluster at mongodb.com/atlas, then copy its connection string.
2. `cp .env.example .env` and paste the string into `MONGODB_URI`.
3. `npm install && npm start`, then open http://localhost:3000

Projects are seeded into the database on the first start (see `seed` in `server.js`).
Contact-form messages are saved in the `messages` collection.

## Deploy (Render)
1. Push this folder to a GitHub repo.
2. On render.com: New > Web Service > pick the repo.
3. Build command `npm install`, start command `npm start`.
4. Add the environment variable `MONGODB_URI`.
5. In Atlas > Network Access, allow access from your host (0.0.0.0/0 for a simple setup).

## Customize
Add `github` / `live` URLs to each project in `seed` (before the first start) or edit the documents in Atlas.
